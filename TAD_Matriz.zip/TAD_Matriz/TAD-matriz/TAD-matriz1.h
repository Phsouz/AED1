#include <stdio.h>
#include <stdlib.h>

// DADOS
typedef struct{
    int **m;
    int linhas;
    int colunas;

} Matriz;

//OPERAÇÕES (PROTÓTIPOS)

Matriz *matriz_cria(int linhas, int colunas);
void matriz_atribui(Matriz *m, int lin, int col, int valor);
int matriz_acessa1(Matriz *m, int lin, int col);
void matriz_acessa2(Matriz *m, int lin, int col, int *end);
void matriz_imprime(Matriz *m);
int matriz_linhas(Matriz* m);
int matriz_colunas(Matriz* m);

void matriz_map1(Matriz* m, void(*funcao)(int*));
void matriz_map2(Matriz* m, int(*funcao)(int));

void vetor_linha(Matriz *m, int lin, int **vetor, int *elem);
void vetor_coluna(Matriz *m, int col, int **vetor, int *elem);
void imprime_vetor(int *v, int tam);
Matriz* matriz_multiplica(Matriz* a, Matriz* b);

int matriz_ehQuadrada(Matriz* m);
int matriz_ehDiagonal(Matriz* m);
int matriz_ehIdentidade(Matriz* m);
Matriz* matriz_transposta(Matriz* m);
Matriz* matriz_oposta(Matriz* m);
void matriz_destroi(Matriz *m);

//OPERAÇÕES (IMPLEMENTAÇÃO)
Matriz *matriz_cria(int linhas, int colunas) {
	int i;
	Matriz *mat = (Matriz*)malloc(sizeof(Matriz));
	mat->linhas = linhas;
	mat->colunas = colunas;
	mat->m = (int**)calloc(linhas, sizeof(int*));
	for (i = 0; i < linhas; i++) {
		mat->m[i] = (int *)calloc(colunas, sizeof(int));
	}

	return mat;
}

void matriz_atribui(Matriz *m, int lin, int col, int valor) {
	m->m[lin][col] = valor;
}

int matriz_acessa1(Matriz *m, int lin, int col) {
	return m->m[lin][col];
}


void matriz_acessa2(Matriz *m, int lin, int col, int *end) {
	*end = m->m[lin][col];
}

void matriz_imprime(Matriz *m) {
	int i, j;
	for (i = 0; i < m->linhas; i++) {
		printf("[");
		for (j = 0; j < m->colunas; j++) {
			printf("%d ", m->m[i][j]);
		}
		printf("]\n");
	}
	printf("\n");
}

int matriz_linhas(Matriz* m) {
	return m->linhas;
}

int matriz_colunas(Matriz* m) {
	return m->colunas;
}

void vetor_linha(Matriz *m, int lin, int **vetor, int *elem) {
	int i, j=0;
	*elem = m->colunas;
	*vetor = (int*)calloc(m->colunas, sizeof(int));

	for (i = 0; i < m->linhas; i++) {
		(*vetor)[i] = m->m[lin][j++];
	}
}

void vetor_coluna(Matriz *m, int col, int **vetor, int *elem) {
	int i, j = 0;
	*elem = m->linhas;
	*vetor = (int*)calloc(m->linhas, sizeof(int));

	for (i = 0; i < m->colunas; i++) {
		(*vetor)[i] = m->m[j++][col];
	}
}

void imprime_vetor(int *v, int tam){
	int i;
	printf("[");
	for(i=0;i<tam;i++){
		printf("%d ", v[i]);
	}
	printf("]\n\n");
}


Matriz* matriz_multiplica(Matriz* a, Matriz* b) {
	if (a->linhas != b->colunas) return 0;
	int i, j, k;
	Matriz *c = matriz_cria(a->linhas, b->colunas);

	for (i = 0; i < a->linhas; i++) {
		for (j = 0; j < b->colunas; j++) {
			for (k = 0; k < b->colunas; k++) {
				c->m[i][j] += (a->m[i][k] * b->m[k][j]);
			}
		}
	}

	return c;
}

/*int matriz_ehQuadrada(Matriz* m) {
	if (m->linhas == m->colunas) return 1;
	else return 0;
}

int matriz_ehDiagonal(Matriz* m) {
	int i, j;
	for (i = 0; i < m->linhas; i++) {
		for (j = 0; j < m->colunas; j++) {
			if (i != j && m[i][j] != 0) {
				return 0;
			}
		}
	}
	return 1;
}

int matriz_ehIdentidade(Matriz* m) {
	int i, j;
	for (i = 0; i < m->linhas; i++) {
		for (j = 0; j < m->colunas; j++) {
			if (i == j && m[i][j] != 1) return 0;
			if (i != j && m[i][j] != 0) return 0;
		}
	}
	return 1;
}


Matriz* matriz_transposta(Matriz* m) {
	int i, j;
	Matriz *mtransp = matriz_cria(m->linhas, m->colunas);

	for (i = 0; i < m->linhas; i++) {
		for (j = 0; j < m->colunas; j++) {
			mtransp[i][j] = m[j][i];
		}
	}

	return mtransp;
}

Matriz* matriz_oposta(Matriz* m) {
	int i, j;
	Matriz *mopst = matriz_cria(m->linhas, m->colunas);

	for (i = 0; i < m->linhas; i++) {
		for (j = 0; j < m->colunas; j++) {
			if (m->m[i][j] > 0) {
				mopst[i][j]=m->m[i][j]*-1
			}
			else {
				mopst[i][j] = m->m[i][j];
			}
		}
	}

	return mopst;
}




void matriz_destroi(Matriz *m) {
	free(m);
}*/














/*Matriz *matriz_cria(int linhas, int colunas)
{
    Matriz *mat = (Matriz *)malloc(sizeof(Matriz));
    mat->m = (int **)calloc(linhas, sizeof(int *));
    int i;
    for (i = 0; i < linhas; i++)
    {
        mat->m[i] = (int *)calloc(colunas, sizeof(int));
    }
    mat->linhas = linhas;
    (*mat).colunas = colunas;

    return mat;
}*/
