#include <stdio.h>

#include "TAD-matriz1.h"
//#include "TAD-matriz2.h"

int main()
{

    // criar matriz
    // int m[2][2]

    Matriz *m1 = matriz_cria(2, 3);
    Matriz *m2 = matriz_cria(10, 10);
    Matriz *m3 = matriz_cria(2, 2);

    // atribui valores nas celulas
    // m[0][2] = 10;
    matriz_atribui(m1, 0, 1, 10);
    matriz_atribui(m2, 2, 3, 20);
    matriz_atribui(m3, 0, 0, 50);

    // acessar valores das celulas
    // int x = m[1][2]
    int x1 = matriz_acessa1(m1, 0, 1);
    printf("%d\n\n", x1);

    int x2;
    matriz_acessa2(m1, 0, 1, &x2);
    printf("%d\n\n", x2);

    //int y = matriz_acessa1(m2, 2, 3);
    //int z = matriz_acessa1(m3, 0, 0);

    // imprimir a matriz
    matriz_imprime(m1);
    matriz_imprime(m2);
    matriz_imprime(m3);

	//recupera linhas
	int x3 = matriz_linhas(m1);
    printf("%d\n\n", x3);

	int x4 = matriz_linhas(m2);
    printf("%d\n\n", x4);

	int x5 = matriz_linhas(m3);
    printf("%d\n\n", x5);

	//recupera colunas
	int x6 = matriz_colunas(m1);
    printf("%d\n\n", x6);

	int x7 = matriz_colunas(m2);
    printf("%d\n\n", x7);

	int x8 = matriz_colunas(m3);
    printf("%d\n\n", x8);

	//alterar elementos matriz


	//vetor a partir da linha da matriz
	int *v1, elem1;
	vetor_linha(m1, 1, &v1, &elem1);

	//vetor a partir da coluna da matriz
	int *v2, elem2;
	vetor_coluna(m2, 2, &v2, &elem2);
   

	//Multiplicar matrizes
	Matriz *m4 = matriz_multiplica(m1, m2);
    matriz_imprime(m4);

    /* destruir matriz
    //matriz_destroi(m1);
    //matriz_destroi(m2);
    matriz_destroi(m3);*/

}